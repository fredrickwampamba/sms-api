
<?php 

	$username="testuser";
	$password="test456";
	$senderid="Test";
	$numbers="256702014626,2567064903907,256785006537";
	$message="You are Invited for 2nd last introduction preparatory meeting of Ssentongo Henry 22/4/18, 4pm Kasubi-Kawaala home of Mr and Mrs Kyeyune. come with your pledge";

	
	$data= array(
		'user'=> array(
			'username'=>'joetell',// genius username 
			'password'=>'123456' //genius sms password 
			), 
		'messages'=> array(
			array(
				'numbers'=>array('2567064903907','256702014626','256785006537'), 
				'message-body'=>'HELLO GENIUS', 
				'senderid'=>'GENIUS'), 
			array(
				'numbers'=>array('2567064903907'), 
				'message-body'=>$message, 
				'senderid'=>'Hi') 
				) 
			);
	
	
	
	//encode the array into json 
	$json_builder =json_encode($data); 
	//use curl to post the the json encoded information 
	$ch = curl_init('http://geniussmsgroup.com/api/json/messages/jsonMessagesService'); 
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
	curl_setopt($ch, CURLOPT_HEADER, 0); curl_setopt($ch, CURLOPT_POST, 1); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $json_builder); 
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	$ch_result = curl_exec($ch); curl_close($ch); 
	//print an array that is json decoded 
	print_r(json_decode($ch_result,true)); 
	
	
?>
	