
<?php
$url = "http://geniussmsgroup.com/api/http/messagesService/get?username=testuser&password=test345&senderid=SMS&numbers=256785006537,256706493907&message=Message+One";
$response = file_get_contents($url);

//$response = file($url); 

//$parse_url=file($live_url);
echo $response;

?>