

<?php
$time_send=time();


$xml_1 = '<request>
	<user>
		<username>testuser</username>
		<password>test456</password>
	</user>
	<messages>
		<message>
			<senderid>Developer</senderid>
			<message-body>Hello API Developer Test</message-body>
			<numbers>
				<number>256785006537</number>
				<number>256706493907</number>
				<number>256702014626</number>
			</numbers>
		</message>
	</messages>
</request>';

$xml_2 = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<request>
	<user>
		<username>testuser</username>
		<password>test456</password>
	</user>
	<messages>
		<message>
			<numbers>
				<number>256785006537</number>
				<number>256702014626</number>
			</numbers>
			<message-body>Developer Test SMS </message-body>
			<senderid>Test SMS</senderid>
		</message>
		<message>
			<numbers>
				<number>256702014626</number>
			</numbers>
			<message-body>Hello API Developers</message-body>
			<senderid>Developer</senderid>
		</message>
		<message>
			<numbers>
				<number>256785006537</number>
				<number>256706493907</number>
			</numbers>
			<message-body>More Contacts List</message-body>
			<senderid>More</senderid>
		</message>
	</messages>
</request>'

//use curl to post the xml information 

//$ch = curl_init('http://212.71.239.24:8080/egosms/api/xml/messages/xmlMessagesService');
//$ch = curl_init('http://192.168.0.103:8484/egosms/api/xml/v2/messages/xmlV2MessagesService');
//$ch = curl_init('http://212.71.239.24:8080/egosms/api/xml/v1/messages/xmlV1MessagesService');

$ch = curl_init('http://geniussmsgroup.com/api/xml/messages/xmlMessagesService');

curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/xml'));
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $xml_2);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$ch_result = curl_exec($ch);
curl_close($ch);
echo  $ch_result;

echo $time_send ;
	//$xml_array =new SimpleXMLElement( $ch_result );  
	//print the array that has been converted from xml
	//print_r(json_decode(json_encode($xml_array), true));


?>